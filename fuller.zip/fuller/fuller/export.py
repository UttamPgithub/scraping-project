import datetime
import os

import numpy as np
import pymongo
import pymysql
import pandas as pd
# dt = "2022_11_15"
d = str(datetime.date.today()).replace('-','')
month_text = datetime.datetime.today().strftime('%B')

from mymodules._common_ import c_replace
# con = pymysql.connect(host="localhost", user="root", password="xbyte", database="fullers",charset='utf8')
conn = pymongo.MongoClient('mongodb://ajay.rajpoot:Ql$p$rYe@192.168.0.50:27017/?authSource=admin')
db = conn["oxford_p_hp_gb_260_1"]
table = "op_3875_fullers_data_18_00_2025_05_20"
# collection = db["op_3875_fullers_data_"]
# qr = f"select * from Fullers.data_2024_03_13_"
collection = db[table]
cursor = collection.find()
df = pd.DataFrame(cursor)
df.pop('_id')
df.index.name = 'Id'
df.reset_index(inplace=True)
df.No = np.arange(1, len(df) + 1)
# df = c_replace(df)
NEW_LIST = ["Id","outlet_name","longitude","latitude","address_1","zonal","sales_id","menu_id","city","postcode","section","subsection","product","`menu`","disrecord_id","product_id","Item_id","Item_type","epos_name","portion_name","price","Stock","scrape_datetime","path"]
df = df.reindex(columns=NEW_LIST)
df = df.rename(columns={"`menu`":"menu"})
# df = pd.read_sql(qr, con)
df = df.replace({'\n': '', '\t': '', '\r': ''}, regex=True)
df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

path_list = [fr'\\192.168.1.20\DataGators\Projects\[XB52] Oxford Partners - 19 Mobile Apps\QA\2025\{month_text}\\',fr"E:\uttam\working\fuller\files_fuller\\"]
for path in path_list:
    os.makedirs(path,exist_ok=True)
    Writer = pd.ExcelWriter(path+ f'Fullers_{d}.xlsx', engine='xlsxwriter', options={'strings_to_urls': False} )

    csv_path = path + f'Fullers_{d}.csv'
    try:
        df.pop('hashid')
    except:
        pass

    try:
        df.pop('STATUS')
    except:
        pass
    df['Id'] = [f"{i + 1}" for i in range(len(df))]

    df.to_csv(csv_path, index=False, encoding='utf_8_sig')
    df.to_excel(Writer, index=False )
    Writer.close()
    Writer.save()
    print("ok")
    try:
        df.pop('path')
    except:
        pass
