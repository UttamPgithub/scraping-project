# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import datetime

import pymongo
# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import pymysql
d = str(datetime.date.today()).replace('-','_')
from fuller.items import FullerItem,FullermenuItem,FulleraItem,FullerdataItem
class FullerPipeline:
    host = "localhost"
    passwd = "xbyte"
    uname = "root"
    con1 = pymysql.connect( host=host, user=uname, password=passwd )

    today = datetime.datetime.today().strftime("%Y_%m")

    db_name = "fullers"
    main_links=f"main_links_{today}"
    menu_id_new=f"menu_id_{today}"
    item_id=f"item_id_{today}"
    data=f"data_{today}"
    def __init__(self):
        try:
            self.con1.cursor().execute( f"CREATE DATABASE IF NOT EXISTS {self.db_name}" )
            con = pymysql.connect( host=self.host, user=self.uname, password=self.passwd, database=f'{self.db_name}' )
            crsr = con.cursor()

            CT3 = f"""CREATE TABLE IF NOT EXISTS {self.main_links}(  
                                                 `Id` int(11) NOT NULL AUTO_INCREMENT,
                                                  `name` varchar(222) DEFAULT NULL,
                                                  `slug` varchar(255) DEFAULT NULL,
                                                  `orderid` varchar(255) DEFAULT NULL,
                                                  `zonalid` varchar(255) DEFAULT NULL,
                                                  `salesid` varchar(255) DEFAULT NULL,
                                                  `lon` varchar(255) DEFAULT NULL,
                                                  `lat` varchar(255) DEFAULT NULL,
                                                  `address` varchar(255) DEFAULT NULL,
                                                  `city` varchar(255) DEFAULT NULL,
                                                  `postcode` varchar(255) DEFAULT NULL,
                                                  `crmid` varchar(255) DEFAULT NULL,
                                                  `exsiteref` varchar(225) DEFAULT NULL,
                                                  `path` varchar(255) DEFAULT NULL,
                                                  `status` varchar(15) DEFAULT 'pending',
                                                  PRIMARY KEY (`Id`)
                                                ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4"""
            crsr.execute( CT3 )

            CT3 = f"""CREATE TABLE IF NOT EXISTS {self.menu_id_new}(  
                                              `Id` int(11) NOT NULL AUTO_INCREMENT,
                                              `name` varchar(255) DEFAULT NULL,
                                              `zonalid` varchar(255) DEFAULT NULL,
                                              `salesid` varchar(255) DEFAULT NULL,
                                              `menuid` varchar(255) DEFAULT NULL,
                                              `menuname` varchar(255) DEFAULT NULL,
                                              `long` varchar(255) DEFAULT NULL,
                                              `lat` varchar(255) DEFAULT NULL,
                                              `address` varchar(255) DEFAULT NULL,
                                              `city` varchar(255) DEFAULT NULL,
                                              `postcode` varchar(255) DEFAULT NULL,
                                              `path` varchar(255) DEFAULT NULL,
                                              `status` varchar(255) DEFAULT 'pending',
                                              PRIMARY KEY (`Id`)
                                            ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4"""
            crsr.execute( CT3 )
            CT3 = f"""CREATE TABLE IF NOT EXISTS {self.item_id}(  
                                                      `Id` int(11) NOT NULL AUTO_INCREMENT,
                                                      `main_name` varchar(255) DEFAULT NULL,
                                                      `long` varchar(255) DEFAULT NULL,
                                                      `lat` varchar(255) DEFAULT NULL,
                                                      `address` varchar(255) DEFAULT NULL,
                                                      `zonal` varchar(255) DEFAULT NULL,
                                                      `sales` varchar(255) DEFAULT NULL,
                                                      `menuid` varchar(255) DEFAULT NULL,
                                                      `city` varchar(255) DEFAULT NULL,
                                                      `postcode` varchar(255) DEFAULT NULL,
                                                      `Groupid` varchar(255) DEFAULT NULL,
                                                      `Groupname` varchar(255) DEFAULT NULL,
                                                      `sub_cat` varchar(255) DEFAULT NULL,
                                                      `Name` varchar(255) DEFAULT NULL,
                                                      `menuname` varchar(255) DEFAULT NULL,
                                                      `disrecordid` varchar(255) DEFAULT NULL,
                                                      `Product_id` varchar(255) DEFAULT NULL,
                                                      `Itemid` varchar(255) DEFAULT NULL,
                                                      `ItemType` varchar(255) DEFAULT NULL,
                                                      `stock` varchar(255) DEFAULT NULL,
                                                      `hashid` varchar(10) DEFAULT NULL,
                                                      `path` varchar(255) DEFAULT NULL,
                                                      `status` varchar(10) DEFAULT 'pending',
                                                      PRIMARY KEY (`Id`),
                                                      UNIQUE KEY `hashid` (`hashid`)
                                                    ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4"""
            crsr.execute( CT3 )

            CT4 = f"""CREATE TABLE IF NOT EXISTS {self.data}(  
                                                  `Id` int(11) NOT NULL AUTO_INCREMENT,
                                                  `outlet_name` varchar(255) DEFAULT NULL,
                                                  `longitude` varchar(255) DEFAULT NULL,
                                                  `latitude` varchar(255) DEFAULT NULL,
                                                  `address_1` varchar(255) DEFAULT NULL,
                                                  `zonal` varchar(255) DEFAULT NULL,
                                                  `sales_id` varchar(255) DEFAULT NULL,
                                                  `menu_id` varchar(255) DEFAULT NULL,
                                                  `city` varchar(255) DEFAULT NULL,
                                                  `postcode` varchar(255) DEFAULT NULL,
                                                  `section` varchar(255) DEFAULT NULL,
                                                  `subsection` varchar(255) DEFAULT NULL,
                                                  `product` varchar(255) DEFAULT NULL,
                                                  `menu` varchar(255) DEFAULT NULL,
                                                  `disrecord_id` varchar(255) DEFAULT NULL,
                                                  `product_id` varchar(255) DEFAULT NULL,
                                                  `Item_id` varchar(255) DEFAULT NULL,
                                                  `Item_type` varchar(255) DEFAULT NULL,
                                                  `epos_name` varchar(255) DEFAULT NULL,
                                                  `portion_name` varchar(255) DEFAULT NULL,
                                                  `price` varchar(11) DEFAULT NULL,
                                                  `stock` varchar(255) DEFAULT NULL,
                                                  `hashid` varchar(10) DEFAULT NULL,
                                                  `path` varchar(255) DEFAULT NULL,
                                                  `status` varchar(10) DEFAULT 'pending',
                                                  `scrape_datetime` timestamp NULL DEFAULT NULL,
                                                  PRIMARY KEY (`Id`),
                                                  UNIQUE KEY `hashid` (`hashid`)
                                                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                                                """
            crsr.execute( CT4 )


        except Exception as e:
            print( e )




    def process_item(self, item, spider):
        if isinstance(item, FullermenuItem):
            try:
                con = pymysql.connect(host=self.host, user=self.uname, password=self.passwd,
                                      database=f'{self.db_name}')
                crsr = con.cursor()
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = f"insert into {self.menu_id_new}" + "( " + fields + " ) values ( '" + values + "' )"
                print(insert_db)
                crsr.execute(insert_db)
                con.commit()
            except Exception as e:
                print(str(e))
        if isinstance( item, FullerItem ):
            try:
                con = pymysql.connect( host=self.host, user=self.uname, password=self.passwd,
                                       database=f'{self.db_name}' )
                crsr = con.cursor()
                field_list = []
                value_list = []
                for field in item:
                    field_list.append( str( field ) )
                    value_list.append( str( item[field] ).replace( "'", "’" ) )
                fields = ','.join( field_list )
                values = "','".join( value_list )
                insert_db = f"insert into {self.main_links}" + "( " + fields + " ) values ( '" + values + "' )"
                print( insert_db )
                crsr.execute( insert_db )
                con.commit()
            except Exception as e:
                print( str( e ) )


        if isinstance( item, FulleraItem ):
            try:
                con = pymysql.connect( host=self.host, user=self.uname, password=self.passwd,
                                       database=f'{self.db_name}' )
                crsr = con.cursor()
                field_list = []
                value_list = []
                for field in item:
                    field_list.append( str( field ) )
                    value_list.append( str( item[field] ).replace( "'", "’" ) )
                fields = ','.join( field_list )
                values = "','".join( value_list )
                insert_db = f"insert into {self.item_id}" + "( " + fields + " ) values ( '" + values + "' )"
                print( insert_db )
                crsr.execute( insert_db )
                con.commit()
            except Exception as e:
                print( str( e ) )
        if isinstance( item, FullerdataItem ):
            try:
                conn = pymongo.MongoClient('mongodb://uttam.prajapati:T6*48%26%23-@192.168.0.50:27017/?authMechanism=DEFAULT')
                db = conn["oxford_p_hp_gb_260_1"]
                Month = datetime.datetime.today().strftime("%m")
                years = datetime.datetime.today().strftime("%Y")
                table = db[f"op_3875_fullers_data_18_00_{years}_{Month}_20"]
                # crsr = con.cursor()
                # field_list = []
                # value_list = []
                # for field in item:
                #     field_list.append( str( field ) )
                #     value_list.append( str( item[field] ).replace( "'", "’" ) )
                # fields = ','.join( field_list )
                # values = "','".join( value_list )
                # insert_db = f"insert into {self.data}" + "( " + fields + " ) values ( '" + values + "' )"
                # print( insert_db )
                # crsr.execute( insert_db )
                # con.commit()
                try:
                    table.create_index('hashid', unique=True)
                    table.insert_one(dict(item))
                except Exception as E:
                    print(E)
            except Exception as e:
                print( str( e ) )

        return item
