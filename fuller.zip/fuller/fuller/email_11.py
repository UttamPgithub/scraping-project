import json
import os
import re


import pandas as pd
import requests


from datetime import datetime, timedelta
# import pendulum
last_month = (datetime.now() - timedelta(days=30)).strftime('%B')
test_date = datetime.today().strftime('%B')
import datetime
from datetime import timedelta

def email():
    global datetime

    def get_size(path):
        try:
            size = os.stat(path).st_size
            if size < 1024:
                return f"{size} bytes"
            elif size < pow(1024, 2):
                return f"{round(size / 1024, 2)} KB"
            elif size < pow(1024, 3):
                return f"{round(size / (pow(1024, 2)), 2)} MB"
            elif size < pow(1024, 4):
                return f"{round(size / (pow(1024, 3)), 2)} GB"
        except:
            return "0"

    try:

        month = test_date  # =========> Todo Manually Change here
        # month = 'December'  # =========> Todo Manually Change here
        month_last_delivery = last_month  # =========> Todo Manually Change here
        # month_last_delivery = 'November'  # =========> Todo Manually Change here
        SiteName = 'Fuller'  # =========> Todo Manually Change here

        to = ["alison@oxford-partnership.com", "aaron@oxford-partnership.com", "henry@oxford-partnership.com"]

        cc = ["heena.thakor@xbyte.io", "pruthak.acharya@xbyte.io", "nikhil.trivedi@xbyte.io", "forward.pc@xbyte.io",
              "bhavesh.parekh@xbyte.io", "anil.prajapati@xbyte.io", "ricky.jones@xbyte.io", "alpesh.khunt@xbyte.io",
              "victor.douglas@xbyte.io", "saransh.verma@xbyte.io"]

        bcc = ["ankit.mochi@xbyte.io", "vikram.chauhan@xbyte.io", "nilesh.koshti@xbyte.io", "vishal.chanawala@xbyte.io",
               "uttam.prajapati@xbyte.io", "narayanlal.purohit@xbyte.io"]

        # to = ["uttam.prajapati@xbyte.io"]
        # bcc= ["uttam.prajapati@xbyte.io"]
        # cc = ["uttam.prajapati@xbyte.io"]

        total_count_today = 0
        total_count_yesterday = 0
        field_count_today = {}
        prev_field_count_yesterday = {}
        file_list_today = [
            # fr"\\192.168.2.249\DataGators\Temp\Bhagyashree\2023\Oxford\Final_file\{month}\TheLounges_13122023.xlsx",
            fr"\\192.168.1.20\DataGators\Projects\[XB52] Oxford Partners - 19 Mobile Apps\QA_Done\2025\{month}\Fullers_20250512.csv"
        ]#Todo Manually Change here filename

        all_dict_list_today = list()
        all_dict_total_list_today = list()
        all_File_sizes = []
        file_count = []
        file_name = []
        for i in file_list_today:
            try:
                dfF = pd.read_csv(i)
                dfF.dropna()
                Flen = len(dfF)
                today_file_count = file_count.append(Flen)
                field_count = dfF.count(axis=0).to_dict()
                all_dict_list_today.append(field_count)
                total_count_today += Flen
                Flen = total_count_today

                full_name = os.path.basename(i)
                file_name1 = os.path.splitext(full_name)[0]
                file_name.append(file_name1)
                today_file = pd.DataFrame(dfF)
                count = len(today_file)
                today_count = today_file.count(axis=0)
                unique_cnt = today_file.nunique(axis=0)
            except Exception as e:
                print('error in Todays file read : ', e)
                Flen = 0
                Flen = 0
                today_count = 0
                count = 0
                unique_cnt = 0

            size = get_size(i)
            all_File_sizes.append(size)

        df_list_today = pd.DataFrame(all_dict_list_today)
        for a in list(df_list_today):
            coloum_values = df_list_today[a].tolist()
            today_column_sum = df_list_today[a].sum()
            all_dict_total_list_today.append(today_column_sum)

        file_list_yesterday = [
            # fr"\\192.168.2.249\DataGators\Temp\Bhagyashree\2023\Oxford\Final_file\{month_last_delivery}\TheLounges_16112023.xlsx",
            fr"\\192.168.1.20\DataGators\Projects\[XB52] Oxford Partners - 19 Mobile Apps\QA_Done\2025\{month_last_delivery}\Fullers_20250414.csv"

        ]#Todo Manually Change here filename


        all_dict_list_yesterday = list()
        for j in file_list_yesterday:

            try:
                dfO = pd.read_csv(j)
                dfO.dropna()
                Olen = len(dfO)
                today_file_count = file_count.append(Olen)
                prev_field_count = dfO.count(axis=0).to_dict()
                all_dict_list_yesterday.append(prev_field_count)
                total_count_yesterday += Olen
                Olen = total_count_yesterday
                full_name = os.path.basename(j)
                file_name2 = os.path.splitext(full_name)[0]
                file_name.append(file_name2)
                previous_file = pd.DataFrame(dfO)
                previous_count = previous_file.count(axis=0)
            except Exception as e:
                print('dfO.......', e)
                Olen = 0
                previous_count = 0

            size = get_size(j)
            all_File_sizes.append(size)

        df_list_yesterday = pd.DataFrame(all_dict_list_yesterday)
        all_dict_total_list_yeterday = list()
        for b in list(df_list_yesterday):
            coloum_values = df_list_yesterday[b].tolist()
            yesterday_column_sum = df_list_yesterday[b].sum()
            all_dict_total_list_yeterday.append(yesterday_column_sum)

        previous_5_dict = {}

        previous_5_dict['Filename'] = file_name
        previous_5_dict['Count'] = file_count
        previous_5_dict['FileSize'] = all_File_sizes
        previous_5_dict_df = pd.DataFrame.from_dict(previous_5_dict)

        cnt_df = pd.concat([today_count, previous_count, unique_cnt], axis=1).reset_index(drop=True)
        cnt_df = cnt_df.rename(columns={0: 'Today count', 1: 'Previous count', 2: 'Unique_Count_a'})
        cnt_df['Difference'] = cnt_df['Today count'] - cnt_df['Previous count']
        cnt_df['Blank count'] = ((((count - cnt_df['Today count']) * 100) / count).round(2)).astype(str) + '%'
        cnt_df['Unique Count'] = ((((cnt_df['Unique_Count_a']) * 100) / count).round(2)).astype(str) + '%'
        try:
            cnt_df.pop('Unique_Count_a')
        except:
            pass
        total_len = {}
        total_len["Today's Count"] = [Flen]
        total_len["Previous Count"] = [Olen]
        b_df = pd.DataFrame.from_dict(total_len)

        url = 'http://192.168.0.39:5020/exclusive_graph/'
        todaydate= datetime.datetime.now().strftime("%d/%m/%Y")
        payload = {
            "df_main": [json.loads(cnt_df.to_json(orient='records'))],
            "df_name": ['Header Wise Count'],
            "df_header": json.loads(previous_5_dict_df.to_json(orient='records')),
            "df_header_name": 'Datawise Count comparison:',
            "label_arr": [
                ['Id', 'outlet_name', 'longitude', 'latitude', 'address_1', 'zonal', 'sales_id', 'menu_id', 'city', 'postcode', 'section', 'subsection', 'product', 'menu', 'disrecord_id', 'product_id', 'Item_id', 'Item_type', 'epos_name', 'portion_name', 'price', 'stock','scrape_datetime']],
            "project_name": f"Oxford Partners - ({SiteName})", ##ALl chnage your feed name
            "pro_active_subject": f"[ALERT:52] Oxford Partners - Monthly- Delivery  Report Date :{todaydate}",
            "client_name": 'Aaron - AlisonJordan - rafat',
            "graph_flag": "Yes",
            "client_io_flag": "Yes",
            "Alert_code": "52",
            "graph_type": "bar",
            "to_arr": to,
            "cc_arr": cc,
            "bcc_arr": bcc,
            "header_box_label": ["Today's Count", "Previous Count"],
            "header_box_value": [f'{Flen}', f'{Olen}'],
            "extra_params_arr": '',
        }

        headers = {
            "Content-Type": "application/json"
        }

        data = json.dumps(payload)
        response = requests.post(url, data=data, headers=headers)

        print(response.status_code)
        print(response.text)


    except Exception as e:
        print(e)


if __name__ == '__main__':
    email()



