import datetime
import hashlib
import json
import os

from fuller.items import FulleraItem
import pymysql
import requests
import scrapy

import pandas as pd
today_date_slug = pd.Timestamp.now().floor('60min').strftime('%d-%m-%Y')
class MenudataSpider(scrapy.Spider):
    name = 'menudata'
    start_urls = ['https://www.example.com/']

    def __init__(self, start, end):

        self.start = start
        self.end = end
    def parse(self, response):
        connection = pymysql.connect( host='localhost', database='fullers', user='root', password='xbyte' )
        today = datetime.datetime.today().strftime("%Y_%m")
        sql_select_Query=f"SELECT * FROM fullers.menu_id_{today} WHERE status='pending' limit {self.start} , {self.end}"
        cur = connection.cursor()
        cur.execute( sql_select_Query )
        records = cur.fetchall()
        for row in records:
            id=row[0]
            zonal=row[2]
            salesid=row[3]
            name = row[1]
            menuid=row[4]
            menuname=row[5]
            url = "https://iopapi.zonalconnect.com/"
            payload = "request={\"request\":{\"menuId\":"+str(menuid)+",\"method\":\"getmenupages\",\"salesAreaId\":"+str(salesid)+",\"siteId\":\""+str(zonal)+"\",\"config\":{\"headers\":{\"Content-Type\":\"application/x-www-form-urlencoded\",\"Accept\":\"application/json\",\"X-Auth-BrandToken\":\"b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==\",\"X-iOrder-User-Agent\":\"Orderbee - Orderbee - Fullers\"},\"iOrderUrl\":\"https://iopapi.zonalconnect.com/\"},\"bundleIdentifier\":\"com.orderbee.fullers\",\"userDeviceIdentifier\":\"s6wcn-L4dmZs6yRVk9898\",\"platform\":\"Orderbee\"}}"
            #first run this and then run data.py
            # payload = "request={\"request\":{\"menuId\":5070,\"method\":\"getmenupages\",\"salesAreaId\":240,\"siteId\":\"268\",\"config\":{\"headers\":{\"Content-Type\":\"application/x-www-form-urlencoded\",\"Accept\":\"application/json\",\"X-Auth-BrandToken\":\"b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==\",\"X-iOrder-User-Agent\":\"Orderbee - Orderbee - Fullers\"},\"iOrderUrl\":\"https://iopapi.zonalconnect.com/\"},\"bundleIdentifier\":\"com.orderbee.fullers\",\"userDeviceIdentifier\":\"s6wcn-L4dmZs6yRVk9898\",\"platform\":\"Orderbee\"}}"
            # headers = {
            #     'accept':'application/json',
            #     'accept-encoding':'gzip, deflate, br',
            #     'accept-language':'en-US,en;q=0.9,gu;q=0.8',
            #     'cache-control':'no-cache',
            #     'content-length':'487',
            #     'content-type':'application/x-www-form-urlencoded',
            #     'origin':'https://order.fullers.co.uk',
            #     'pragma':'no-cache',
            #     'referer':'https://order.fullers.co.uk/',
            #     'sec-fetch-dest':'empty',
            #     'sec-fetch-mode':'cors',
            #     'sec-fetch-site':'cross-site',
            #     'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
            #     'x-auth-brandtoken':'b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD=="',
            #     'x-iorder-user-agent':'Orderbee - Orderbee - Fullers',
            #     # 'Cookie': 'CFID=251596378; CFTOKEN=cb518abf92bdfed2-00C1D642-5056-AF31-C4FBA78B680CC088; JSESSIONID=B9B6A42167C271501CA2A3A605F666A7.cfusion'
            # }
            headers = {
                'Accept': 'application/json',
                'Accept-Encoding': 'gzip, deflate, br, zstd',
                'Accept-Language': 'en-US,en;q=0.9',
                'Content-Length': '449',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'https://order.fullers.co.uk',
                'Priority': 'u=1, i',
                'Referer': 'https://order.fullers.co.uk/',
                'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
                'Sec-Ch-Ua-Mobile': '?0',
                'Sec-Ch-Ua-Platform': '"Windows"',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'cross-site',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
                'X-Auth-Brandtoken': 'b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==',
                'X-Iorder-User-Agent': 'Orderbee - Orderbee - Fullers'
            }
            response = requests.request( "POST", url, headers=headers, data=payload )

            try:
                path = f'D:\\\\uttam\\\\working\\\\fuller\\\\itemids\\\\{today_date_slug}\\\\'
                if not os.path.exists( path ):
                    os.makedirs( path )
                full_path1 = path + f'{id}_{menuname}_{menuid}.html'
                with open( full_path1, 'w', encoding='utf-8' ) as file:
                    file.write( response.text )
            except Exception as e:
                print( e )
            item=FulleraItem()
            try:
                json_data=json.loads(response.text)
                # print(json_data)
                data=json_data['display']['displayGroups']#
            except Exception as e:
                json_data=""
                print(e)
                # display.displayGroups[0].groupId
            for j in data:
                item['main_name']=name
                item['`long`'] = row[6]
                item['lat'] = row[7]
                item['zonal']=zonal
                item['sales']=salesid
                item['menuid']=menuid
                item['`address`'] = row[8]
                item['`city`'] = row[9]
                item['`postcode`'] = row[10]
                try:
                    item['Groupid']=j['groupId']
                except Exception as e:
                    item['Groupid']=""
                    print(e)
                try:
                    item['Groupname']=j['groupName']
                except Exception as e:
                    item['Groupname']=""
                    print(e)
                dj=j['items']
                # sub_cat1=""
                # sub_cat1 = "Cask Beers" # display.displayGroups[0].items[0].subHeader.text
                item['menuname']=menuname
                sub_cat1=""
                for d in dj:

                    try:
                        sub_category = d['subHeader']['text']
                        sub_cat1 = sub_category
                    except:
                         sub_cat1 = sub_cat1

                    try:
                        item['Name']=d['product']['displayName']
                    except Exception as e:
                        item['Name']=""
                        print(e)
                    try:
                        item['disrecordid']=d['product']['displayRecordId']
                    except Exception as e:
                        item['disrecordid']=""
                        print(e)
                    try:
                        item['Product_id']=d['product']['productId']
                    except Exception as e:
                        item['Product_id']=""
                        print(e)
                    try:
                        item['Itemid']=d['itemId']
                        # display.displayGroups[0].items[1].product.mayStock#display.displayGroups[0].items[0].subHeader.text
                    except Exception as e:
                        item['Itemid']=""
                        print(e)
                    try:
                        Stock=d['product']['mayStock']
                        if Stock =="1" or Stock ==1:
                            item['Stock']="In Stock"
                        else:
                            item['Stock']= "Out of Stock"
                    except Exception as e:
                        print(e)
                    try:
                        item['ItemType']=d['itemType']
                    except Exception as e:
                        item['ItemType']=""
                        print(e)
                    try:
                        item['sub_cat']=sub_cat1
                    except Exception as e:
                        item['sub_cat']=""
                        print(e)
                    item['path']=full_path1
                    try:
                        hid = str( item['Name'] ) + str(item['menuname']  ) + str( item['Product_id'] ) + str(
                            response.url ) + str(item['sub_cat'] ) + (item['main_name']) +str(item['Groupname'])
                        item['hashid'] = int( hashlib.md5( bytes( hid, "utf8" ) ).hexdigest(), 16 ) % (10 ** 8)
                    except Exception as e:
                        print( "Error in hashid", e )
                    yield item
                connection = pymysql.connect( host='localhost', database='fullers', user='root', password='xbyte' )
                crsr = connection.cursor()
                update = f"update fullers.menu_id_{today} set status='done11' where id = '{id}'"
                print(update)
                crsr.execute(update)
                connection.commit()


if __name__=="__main__":
    from scrapy.cmdline import execute
    # execute("scrapy crawl menudata".split())
    execute( "scrapy crawl menudata -a start=0 -a end=10000".split() )