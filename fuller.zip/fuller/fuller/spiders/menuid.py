import datetime
import json
import os

from fuller.items import FullermenuItem
import pymysql
import scrapy
import requests
import pandas as pd
today_date_slug = pd.Timestamp.now().floor('60min').strftime('%d-%m-%Y')
class MenuidSpider(scrapy.Spider):
    name = 'menuid'
    start_urls = ['https://www.example.com/']
    def parse(self, response):
        global item, full_path1
        connection = pymysql.connect( host='localhost', database='fullers', user='root', password='xbyte' )
        today = datetime.datetime.today().strftime("%Y_%m")
        sql_select_Query = f"SELECT * FROM fullers.main_links_{today} WHERE status='pending' "
        cur = connection.cursor()
        cur.execute( sql_select_Query )
        records = cur.fetchall()
        for row in records:
            id=row[0]
            zonal=row[4]
            salesid=row[5]

            url = "https://iopapi.zonalconnect.com/"
            payload = "request={\"request\":{\"method\":\"getMenus\",\"siteId\":\""+str(zonal)+"\",\"salesAreaId\":"+str(salesid)+",\"config\":{\"headers\":{\"Content-Type\":\"application/x-www-form-urlencoded\",\"Accept\":\"application/json\",\"X-Auth-BrandToken\":\"b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==\",\"X-iOrder-User-Agent\":\"Orderbee - Orderbee - Fullers\"},\"iOrderUrl\":\"https://iopapi.zonalconnect.com/\"},\"bundleIdentifier\":\"com.orderbee.fullers\",\"userDeviceIdentifier\":\"s6wcn-L4dmZs6yRVk9898\",\"platform\":\"Orderbee\"}}"

            headers = {
                'accept': "application/json",
                'accept-encoding': "gzip, deflate, br",
                'accept-language': "en-US,en;q=0.9",
                'cache-control': "no-cache",
                'content-length': "469",
                'content-type': "application/x-www-form-urlencoded",
                'origin': "https://order.fullers.co.uk",
                'pragma': "no-cache",
                'referer': "https://order.fullers.co.uk/",
                'sec-ch-ua': "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"100\", \"Google Chrome\";v=\"100\"",
                'sec-ch-ua-mobile': "?1",
                'sec-ch-ua-platform': "\"Android\"",
                'sec-fetch-dest': "empty",
                'sec-fetch-mode': "cors",
                'sec-fetch-site': "cross-site",
                'user-agent': "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Mobile Safari/537.36",
                'x-auth-brandtoken': "b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==",
                'x-iorder-user-agent': "Orderbee - Orderbee - Fullers",
                'postman-token': "47825ed7-c1e2-97de-efff-30868e0205dc"
            }

            response = requests.request( "POST", url, data=payload, headers=headers )
            name = row[1]
            item = FullermenuItem()
            # print( response.text )
            json_data=json.loads(response.text)
            # print(json_data)
            try:
                path = f'D:\\\\uttam\\\\working\\\\fuller\\\\mainid\\\\{today_date_slug}\\\\'
                if not os.path.exists( path ):
                    os.makedirs( path )
                full_path1 = path + f'{id}.html'
                with open( full_path1, 'w', encoding='utf-8' ) as file:
                    file.write( response.text )
            except Exception as e:
                print( e )
            try:
                menu=json_data['menus']
                for k in menu:
                    menuid=k['id']
                    menuname=k['name']
                    item['`name`']=name
                    item['`zonalid`']=zonal
                    item['`salesid`']=salesid
                    item['`menuid`']=menuid
                    item['`menuname`']=menuname
                    item['`path`']=full_path1
                    item['`long`']=row[6]
                    item['lat']=row[7]
                    item['`address`']=row[8]
                    item['`city`']=row[9]
                    item['`postcode`']=row[10]
                    yield item
                connection = pymysql.connect( host='localhost', database='fullers', user='root', password='xbyte' )
                crsr = connection.cursor()
                update = f"update fullers.main_links_{today} set status='done' where id = '{id}'"
                print( update )
                crsr.execute( update )
                connection.commit()
                print( update )
            except Exception as e:
                print(e)
if __name__=="__main__":
    from scrapy.cmdline import execute
    execute("scrapy crawl menuid".split())
    exec(open("menudata.py").read())