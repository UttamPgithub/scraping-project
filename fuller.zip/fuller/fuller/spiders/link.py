import json
import os

import scrapy
from fuller.items import FullerItem
import pandas as pd
today_date_slug = pd.Timestamp.now().floor('60min').strftime('%d-%m-%Y')
class LinkSpider(scrapy.Spider):
    name = 'link'

    def start_requests(self):
        url = "https://cdn.contentful.com/spaces/h49cy5j5vr7r/environments/master/entries?content_type=brand&fields.hostname=order.fullers.co.uk&limit=1&include=3"


        headers = {
            'accept': "application/json, text/plain, */*",
            'accept-encoding': "gzip, deflate, br",
            'accept-language': "en-US,en;q=0.9",
            'authorization': "Bearer 4IvIdi79w0fMRvHElg9UpfLpz8ZnqYULgVxf_YJKYR8",
            'cache-control': "no-cache",
            'origin': "https://order.fullers.co.uk",
            'pragma': "no-cache",
            'referer': "https://order.fullers.co.uk/",
            'sec-ch-ua': "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"100\", \"Google Chrome\";v=\"100\"",
            'sec-ch-ua-mobile': "?1",
            'sec-ch-ua-platform': "\"Android\"",
            'sec-fetch-dest': "empty",
            'sec-fetch-mode': "cors",
            'sec-fetch-site': "cross-site",
            'user-agent': "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Mobile Safari/537.36",
            'x-contentful-user-agent': "sdk contentful.js/9.1.6; platform browser; os Windows;",
            'postman-token': "771d6364-602b-b008-fadd-3b2565e739a8"
        }
        yield scrapy.Request(url=url,callback=self.parse,headers=headers)
    def parse(self, response):
        global full_path1
        a = response.text
        json_data=json.loads(response.text)
        data = json_data['includes']['Entry']
        for i in data:
            item = FullerItem()
            try:
                item['name']=i['fields']['contentfulName']#includes.Entry[390].fields.contentfulName
            except :
                item['name']=""

            try:
                # path = f'D:\\\\fuller\\\\mainlink\\\\'
                path = f'D:\\\\uttam\\\\working\\\\fuller\\\\mainlink\\\\{today_date_slug}\\\\'
                if not os.path.exists( path ):
                    os.makedirs( path )
                full_path1 = path + f'{item["name"]}.html'
                with open( full_path1, 'w', encoding='utf-8' ) as file:
                    file.write( response.text )
            except Exception as e:
                print( e )
            try:
                item['slug']=i['fields']['slug']
            except:
                item['slug']=""
            try:
                item['orderid']=i['fields']['orderbeeId']
            except:
                item['orderid']=""
            try:
                item['zonalid']=i['fields']['zonalSiteId']
            except:
                item['zonalid']=""
            try:
                item['lon']=i['fields']['coordinates']['lon']
            except :
                item['lon']=""
            try:
                item['lat']=i['fields']['coordinates']['lat']
            except :
                item['lat']=""
            try:
                item['address']=i['fields']['addressLine1']
            except:
                item['address']=""
            try:
                item['city']=i['fields']['city']
            except :
                item['city']=""
            try:
                item['postcode']=i['fields']['postalCode']
            except:
                item['postcode']=""
            try:
                item['crmid']=i['fields']['crmId']
            except :
                item['crmid']=""
            try:
                item['exsiteref']=i['fields']['externalSiteRef']
            except:
                item['exsiteref']=""
            item['path']=full_path1
            if item['zonalid']!="":
                yield item
            
from scrapy.cmdline import execute
if __name__=="__main__":
    execute("scrapy crawl link".split())
    exec(open("secmain.py").read())