import hashlib
import json
import os
import datetime
from fuller.items import FullerdataItem
import pymysql
import requests
import scrapy
from mymodules._common_ import c_replace
import pandas as pd
today_date_slug = pd.Timestamp.now().floor('60min').strftime('%d-%m-%Y')
proxy_host = "zproxy.luminati.io"
proxy_port = "22225"
proxy_auth = 'brd-customer-hl_4fc8c816-zone-zone_us:33p04eaqxtpu'
proxies = {
    "https": f"http://{proxy_auth}@{proxy_host}:{proxy_port}/",
    "http": f"http://{proxy_auth}@{proxy_host}:{proxy_port}/"
}
# proxy_list=[ "http://brd-customer-hl_4fc8c816-zone-zone_us:33p04eaqxtpu@zproxy.lum-superproxy.io:22225",
#     "http://brd-customer-xbyte-zone-zone_germany-country-de:33mvqyt5wceu@zproxy.lum-superproxy.io:22225"]
class DataSpider(scrapy.Spider):
    name = 'data'
    start_urls = ['https://www.example.com/']

    def __init__(self, name=None, start="", end="", **kwargs):
        super().__init__(name, **kwargs)
        self.start = start
        self.end = end
    def parse(self, response):
        item=FullerdataItem()
        connection = pymysql.connect( host='localhost', database='fullers', user='root', password='xbyte' )
        today = datetime.datetime.today().strftime("%Y_%m")
        sql_select_Query = f"SELECT * FROM fullers.item_id_{today} WHERE status='pending' limit {self.start} , {self.end}"
        # sql_select_Query="SELECT * FROM fullers.item_id WHERE main_name='Grove Lock Leighton Buzzard' "
                         # "#limit 0,25 "
        # sql_select_Query = f'SELECT * FROM fullers.item_id WHERE main_name="Three Guineas Reading" AND groupname="Winter Tipples" '
        cur = connection.cursor()
        cur.execute( sql_select_Query )
        records = cur.fetchall()
        for row in records:
            id = row[0]
            item['zonal'] = row[5]
            item['sales_id'] = row[6]
            item['menu_id'] = row[7]
            item['city'] = row[8]
            item['postcode'] = row[9]
            item['section'] = row[11]
            item['subsection'] = c_replace(row[12])
            item['product'] = c_replace(row[13])
            item['`menu`'] = row[14]
            item['disrecord_id'] = row[15]
            item['product_id'] = row[16]
            item['Item_id'] = row[17]
            item['Item_type'] = row[18]
            item['outlet_name'] = row[1]
            item['Stock']=row[19]
            item['longitude'] = row[2]
            item['latitude'] = row[3]
            item['address_1'] = row[4]
            url = "https://iopapi.zonalconnect.com/"
            payload = "request={\"request\":{\"menuId\":" + str(
                item['menu_id'] ) + ",\"method\":\"getmenupages\",\"salesAreaId\":" + str( item['sales_id'] ) + ",\"siteId\":\"" + str(
                item['zonal'] ) + "\",\"config\":{\"headers\":{\"Content-Type\":\"application/x-www-form-urlencoded\",\"Accept\":\"application/json\",\"X-Auth-BrandToken\":\"b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==\",\"X-iOrder-User-Agent\":\"Orderbee - Orderbee - Fullers\"},\"iOrderUrl\":\"https://iopapi.zonalconnect.com/\"},\"bundleIdentifier\":\"com.orderbee.fullers\",\"userDeviceIdentifier\":\"s6wcn-L4dmZs6yRVk9898\",\"platform\":\"Orderbee\"}}"
            headers = {
                'accept':'application/json',
                'accept-encoding':'gzip, deflate, br',
                'accept-language':'en-US,en;q=0.9,gu;q=0.8',
                'cache-control':'no-cache',
                'content-length':'487',
                'content-type':'application/x-www-form-urlencoded',
                'origin':'https://order.fullers.co.uk',
                'pragma':'no-cache',
                'referer':'https://order.fullers.co.uk/',
                'sec-fetch-dest':'empty',
                'sec-fetch-mode':'cors',
                'sec-fetch-site':'cross-site',
                'user-agent':'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36',
                'x-auth-brandtoken':'b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==',
                'x-iorder-user-agent':'Orderbee - Orderbee - Fullers',
                'Cookie': 'CFID=251596378; CFTOKEN=cb518abf92bdfed2-00C1D642-5056-AF31-C4FBA78B680CC088; JSESSIONID=B9B6A42167C271501CA2A3A605F666A7.cfusion'
            }
            response = requests.request(method="POST",url=url, data=payload, headers=headers)
            json_data=json.loads(response.text)
            try:

                try:
                    path = f'D:\\\\uttam\\\\working\\\\fuller\\\\data\\\\{today_date_slug}\\\\'
                    if not os.path.exists( path ):
                        os.makedirs( path )
                    full_path1 = path + f'{id}_data.html'
                    with open( full_path1, 'w', encoding='utf-8' ) as file:
                        file.write( response.text )
                except Exception as e:
                    print( e )

                isd=json_data['aztec']['products']
                for i in isd:
                    ida=i['id']

                    if ida==int(item['product_id']):
                    # if ida==item['product_id']:

                        print(ida)
                        print("yes")
                        item['epos_name']=i['eposName']
                        # item['Stock']=i['display.displayGroups[0].items[1].product.mayStock']
                        varien=i['portions']
                        if varien != []:
                            for g in varien:#aztec.products[1].portions[0].price
                                item['portion_name']=g['name']
                                item['price']=g['price']
                                try:
                                    hid = str( item['outlet_name'] ) + str( item['section'] ) + str( item['subsection'] ) + str(
                                        response.url ) + str( item['epos_name'] ) + str(item['price']) +str(item['portion_name'])
                                    item['hashid'] = int( hashlib.md5( bytes( hid, "utf8" ) ).hexdigest(), 16 ) % (10 ** 8)
                                except Exception as e:
                                    print( "Error in hashid", e )
                                item['path']=full_path1
                                try:
                                    item['scrape_datetime'] = datetime.datetime.now()
                                except:
                                    item['scrape_datetime']= ''
                                yield item
                        else:

                            yield item

                        update = f"update fullers.item_id_{today} set status='done1111' where id ='{id}'"
                        print( update )
                        cur.execute( update )
                        connection.commit()
                        # connection.close()
                        # cur.close()
            except Exception as e:
                print(e)


#           update here on product id and name
if __name__=="__main__":
    from scrapy.cmdline import execute
    # execute("scrapy crawl menudata".split())
    execute( "scrapy crawl data -a start=0 -a end=1".split())