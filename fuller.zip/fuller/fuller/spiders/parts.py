# total_count = 56000
# divi = int(total_count /20)
# parts = divi
# for i in range(0, total_count, parts):
#     # with open('E:\\booking\\booking\\spiders\\rooms_data.bat', 'a') as f:
#         print(f'start "{i}" scrapy crawl data -a start={i} -a end={parts}')
#         # f.write(f'start py -m scrapy crawl main -a start={i} -a end={parts}')
#         # f.write('\n')
#         # f.close()
