import json
import os
import datetime

import scrapy
import pymysql
import requests
import pandas as pd
today_date_slug = pd.Timestamp.now().floor('60min').strftime('%d-%m-%Y')
class SecmainSpider(scrapy.Spider):
    name = 'secmain'
    def start_requests(self):
        connection = pymysql.connect( host='localhost', database='fullers', user='root', password='xbyte' )
        # sql_select_Query = f"SELECT * FROM fullers.main_links WHERE salesid='' "
        today = datetime.datetime.today().strftime("%Y_%m")
        sql_select_Query = f"SELECT * FROM fullers.main_links_{today} WHERE salesid is NULL "
        # sql_select_Query = f"SELECT * FROM fullers.main_links WHERE id=38 "
        cur = connection.cursor()
        cur.execute( sql_select_Query )
        records = cur.fetchall()
        for row in records:
            id=row[0]
            name=row[1]
            zonal=row[4]
            url = "https://iopapi.zonalconnect.com/"
            # zonal=68
            # payload = "request={\"request\":{\"method\":\"venues\",\"siteId\""+str(zonal)+":,\"config\":{\"headers\":{\"Content-Type\":\"application/x-www-form-urlencoded\",\"Accept\":\"application/json\",\"X-Auth-BrandToken\":\"b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==\",\"X-iOrder-User-Agent\":\"Orderbee - Orderbee - Fullers\"},\"iOrderUrl\":\"https://iopapi.zonalconnect.com/\"},\"bundleIdentifier\":\"com.orderbee.fullers\",\"userDeviceIdentifier\":\"s6wcn-L4dmZs6yRVk9898\",\"platform\":\"Orderbee\"}}"
            payload = "request={\"request\":{\"method\":\"venues\",\"siteId\":\""+str(zonal)+"\",\"config\":{\"headers\":{\"Content-Type\":\"application/x-www-form-urlencoded\",\"Accept\":\"application/json\",\"X-Auth-BrandToken\":\"b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==\",\"X-iOrder-User-Agent\":\"Orderbee - Orderbee - Fullers\"},\"iOrderUrl\":\"https://iopapi.zonalconnect.com/\"},\"bundleIdentifier\":\"com.orderbee.fullers\",\"userDeviceIdentifier\":\"s6wcn-L4dmZs6yRVk9898\",\"platform\":\"Orderbee\"}}"
            # headers = {
            #     'accept': "application/json",
            #     # 'accept-encoding': "gzip, deflate, br",
            #     'accept-language': "en-US,en;q=0.9",
            #     'cache-control': "no-cache",
            #     # 'content-length': "449",
            #     'content-type': "application/x-www-form-urlencoded",
            #     'origin': "https://order.fullers.co.uk",
            #     'pragma': "no-cache",
            #     # 'referer': "https://order.fullers.co.uk/",
            #     'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            #     'x-auth-brandtoken': "b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==",
            #     'x-iorder-user-agent': "Orderbee - Orderbee - Fullers",
            # }
            headers = {
                'accept': 'application/json',
                'accept-language': 'en-US,en;q=0.9',
                'cache-control': 'no-cache',
                'content-type': 'application/x-www-form-urlencoded',
                'origin': 'https://order.fullers.co.uk',
                'pragma': 'no-cache',
                'priority': 'u=1, i',
                'referer': 'https://order.fullers.co.uk/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
                'x-auth-brandtoken': 'b3JkZXJiZWUtZnVsbGVyczp1OVFYcVI5Rzlja0pkVTlxUjdJeUppUUxD==',
                'x-iorder-user-agent': 'Orderbee - Orderbee - Fullers',
            }

            response = requests.request("POST", url, data=payload, headers=headers)
            a = response.text
            json_data=json.loads(response.text)
            try:
                path = f'D:\\\\uttam\\\\working\\\\fuller\\\\salesid\\\\{today_date_slug}\\\\'
                if not os.path.exists( path ):
                    os.makedirs( path )
                full_path1 = path + f'{id}.html'
                with open( full_path1, 'w', encoding='utf-8' ) as file:
                    file.write( response.text )
            except Exception as e:
                print( e )
            # print(json_data)
            try:
                salesid=json_data['venues'][0]['salesArea'][0]['id']
                print(salesid)
            except :
                salesid=""
            con = pymysql.connect( host="localhost", user="root", password="xbyte",
                                   database="fullers" )
            crsr = con.cursor()
            try:
                update = f"update fullers.main_links_{today} set salesid='{salesid}' where name ='{name}'"
                print(update)
                crsr.execute(update)
                con.commit()
            except Exception as e:
                print(e)



if __name__=="__main__":
    from scrapy.cmdline import execute
    execute("scrapy crawl secmain".split())
    exec(open("menuid.py").read())