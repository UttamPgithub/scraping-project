total_count = 13082
divi = int(total_count / 10)
parts = divi
for i in range(0, total_count, parts):
    # with open('E:\\booking\\booking\\spiders\\rooms_data.bat', 'a') as f:
        # f.write(f'start "{i}" scrapy crawl airline_spider_second -a a={i} -a b={parts}')
    print(f'start scrapy crawl data -a start={i} -a end={parts}')
        # f.write('\n')
        # f.close()
